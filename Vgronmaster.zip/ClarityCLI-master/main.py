#############################
#   Code Dev : Vgron   #
#   Main Dev : Vgron       #
#############################

from platform import system
from time import sleep

from modules.sql_tool import SqlInjectionTools
from modules.wordlist_tools import WordlistTools
from core import *
from modules.xss_tools import XssTools
from tool_manager import ToolManager

#  <-- We commented the backdoor, see?

all_tools = [
    SqlInjectionTools(),
    WordlistTools(),
    XssTools(),
    ToolManager(),
]

class AllTools(VgronToolsCollection):
    TITLE = "All tools"
    TOOLS = all_tools

    def show_info(self):
        clear()
        menu()

if __name__ == "__main__":
    try:
        if system() == 'Windows':
            fpath = os.path.expanduser("~\\vgrontoolpath.txt")
        elif system() == 'Linux':
            fpath = os.path.expanduser("~/.vgrontoolpath")
        else:
            print("Your Platform is not supported")
            sys.exit(0)

        if not os.path.exists(fpath):
            os.system('cls' if system() == 'Windows' else 'clear')
            # run.menu()
            print("""
                    [@] Set Path (All your tools will be installed in that directory)
                    [1] Manual 
                    [2] Default
            """)
            choice = input("Vgron Tool [>] ").strip()

            if choice == "1":
                inpath = input("Enter Path (with Directory Name) >> ").strip()
                with open(fpath, "w") as f:
                    f.write(inpath)
                print("Successfully Set Path to: {}".format(inpath))
            elif choice == "2":
                autopath = "C:\\Vgron-Tool\\" if system() == 'Windows' else "~/.clarity-tool/"
                with open(fpath, "w") as f:
                    f.write(autopath)
                print("Your Default Path Is: {}".format(autopath))
                sleep(3)
            else:
                print("Try Again..!!")
                sys.exit(0)

        with open(fpath) as f:
            archive = f.readline().strip()
            os.makedirs(archive, exist_ok=True)
            os.chdir(archive)
            AllTools().show_options()
    except KeyboardInterrupt:
        print("\nExiting ..!!!")
        sleep(2)

#  Hacking Tool By Vgron
# Design By Zenith